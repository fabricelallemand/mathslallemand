from browser import window
import javascript

WebSocket = javascript.JSConstructor(window.WebSocket)